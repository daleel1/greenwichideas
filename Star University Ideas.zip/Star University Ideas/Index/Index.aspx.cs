﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Star_University_Ideas
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connString;
            if (Convert.ToInt32(Session["IdeaPage"]) == 0)
            {
                Session["IdeaPage"] = 1;
            }
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            //Last logged in time
            if (Session["loggedIn"] != null)
            {
                if (Session["loggedIn"].ToString() == "True" && Session["lastLoggedIn"] != null)
                    {
                        LastLoggedInLabel.Text = "Last Logged In: " + Session["lastLoggedIn"].ToString();
                    }
            }



            //Populate ideas
            OdbcConnection myConnection = new OdbcConnection(connString);
            myConnection.Open();

            string myQuery = "SELECT Idea.IdeaID, Idea.IdeaTitle, Idea.IdeaDescription, Idea.ThumbsUp, Idea.ThumbsDown, Idea.DateMade, Idea.File, category.CategoryString, user.userActive FROM Idea INNER JOIN category ON Idea.CategoryID = Category.CategoryID inner join user ON idea.UserID = user.UserID order BY DateMade DESC";
            OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
            OdbcDataReader reader = myCommand.ExecuteReader();
            double ideanum = 1;
            int dispidea = 0;
            int numberOfIdeas = 0;
            box1.Visible = false;
            box2.Visible = false;
            box3.Visible = false;
            box4.Visible = false;
            box5.Visible = false;
            while (reader.Read())
            {
                if (reader["userActive"].ToString() == "True")
                {
                    numberOfIdeas += 1;
                    int score = 0;
                    string myQuery2 = "SELECT UserVoteID, UserID, IdeaID, Vote FROM uservote";
                    OdbcCommand myCommand2 = new OdbcCommand(myQuery2, myConnection);
                    OdbcDataReader reader2 = myCommand2.ExecuteReader();
                    while (reader2.Read())
                    {
                        if (reader["IdeaID"].ToString() == reader2["IdeaID"].ToString())
                        {
                            score = score + Convert.ToInt32(reader2["Vote"]);
                        }
                    }
                    if (Math.Ceiling(ideanum / 5) == Convert.ToDouble(Session["IdeaPage"]))
                    {
                        dispidea += 1;
                        switch (dispidea)
                        {
                            case 1:
                                box1.Visible = true;
                                idea1.InnerHtml = "";
                                comments1.InnerHtml = "";
                                idea1.InnerHtml += "<h3>" + reader["IdeaTitle"] + " - Current Score = " + score.ToString() + "</h3><p>" + reader["IdeaDescription"] + "</p><div class='thumbnails' id ='buttons" + ideanum + "' runat='server'>";
                                //Populate comments
                                myQuery2 = "Select user.userActive, comment.CommentString FROM comment INNER JOIN user ON comment.userID = user.userID WHERE comment.ideaID = " + reader["IdeaID"];
                                myCommand2 = new OdbcCommand(myQuery2, myConnection);
                                reader2 = myCommand2.ExecuteReader();

                                while (reader2.Read())
                                {
                                    if (reader2["userActive"].ToString() == "True")
                                    {
                                        comments1.InnerHtml += "<div class='comment'><p>" + reader2["CommentString"] + "</p></div>";
                                    }
                                }

                                try
                                {
                                    if (Session["LoggedIn"].ToString() == "True")
                                    {
                                        Button btn = new Button();
                                        btn.ID = "VoteUp" + reader["ideaID"].ToString();
                                        btn.Text = "Vote Up";
                                        btn.Click += new EventHandler(voteUp);
                                        idea1.Controls.Add(btn);

                                        Button btn2 = new Button();
                                        btn2.ID = "VoteDown" + reader["ideaID"].ToString();
                                        btn2.Text = "Vote Down";
                                        btn2.Click += new EventHandler(voteDown);
                                        idea1.Controls.Add(btn2);

                                        tb1.Visible = true;

                                        Button btn3 = new Button();
                                        btn3.ID = "Comment" + reader["ideaID"].ToString();
                                        btn3.CommandArgument = "1";
                                        btn3.Text = "Add Comment";
                                        EventHandler eventHandler = new EventHandler(comment);
                                        btn3.Click += new EventHandler(comment);
                                        addcomment1.Controls.Add(btn3);
                                    }
                                }
                                catch
                                {

                                }
                                break;
                            case 2:
                                box2.Visible = true;
                                idea2.InnerHtml = "";
                                comments2.InnerHtml = "";
                                idea2.InnerHtml += "<h3>" + reader["IdeaTitle"] + " - Current Score = " + score.ToString() + "</h3><p>" + reader["IdeaDescription"] + "</p><div class='thumbnails' id ='buttons" + ideanum + "' runat='server'>";
                                //Populate comments
                                myQuery2 = "Select user.userActive, comment.CommentString FROM comment INNER JOIN user ON comment.userID = user.userID WHERE comment.ideaID = " + reader["IdeaID"];
                                myCommand2 = new OdbcCommand(myQuery2, myConnection);
                                reader2 = myCommand2.ExecuteReader();

                                while (reader2.Read())
                                {
                                    if (reader2["userActive"].ToString() == "True")
                                    {
                                        comments2.InnerHtml += "<div class='comment'><p>" + reader2["CommentString"] + "</p></div>";
                                    }
                                }

                                try
                                {
                                    if (Session["LoggedIn"].ToString() == "True")
                                    {
                                        Button btn = new Button();
                                        btn.ID = "VoteUp" + reader["ideaID"].ToString();
                                        btn.Text = "Vote Up";
                                        btn.Click += new EventHandler(voteUp);
                                        idea2.Controls.Add(btn);

                                        Button btn2 = new Button();
                                        btn2.ID = "VoteDown" + reader["ideaID"].ToString();
                                        btn2.Text = "Vote Down";
                                        btn2.Click += new EventHandler(voteDown);
                                        idea2.Controls.Add(btn2);

                                        tb2.Visible = true;

                                        Button btn3 = new Button();
                                        btn3.ID = "Comment" + reader["ideaID"].ToString();
                                        btn3.CommandArgument = "2";
                                        btn3.Text = "Add Comment";
                                        EventHandler eventHandler = new EventHandler(comment);
                                        btn3.Click += new EventHandler(comment);
                                        addcomment2.Controls.Add(btn3);
                                    }
                                }
                                catch
                                {

                                }
                                break;
                            case 3:
                                box3.Visible = true;
                                idea3.InnerHtml = "";
                                comments3.InnerHtml = "";
                                idea3.InnerHtml += "<h3>" + reader["IdeaTitle"] + " - Current Score = " + score.ToString() + "</h3><p>" + reader["IdeaDescription"] + "</p><div class='thumbnails' id ='buttons" + ideanum + "' runat='server'>";
                                //Populate comments
                                myQuery2 = "Select user.userActive, comment.CommentString FROM comment INNER JOIN user ON comment.userID = user.userID WHERE comment.ideaID = " + reader["IdeaID"];
                                myCommand2 = new OdbcCommand(myQuery2, myConnection);
                                reader2 = myCommand2.ExecuteReader();

                                while (reader2.Read())
                                {
                                    if (reader2["userActive"].ToString() == "True")
                                    {
                                        comments3.InnerHtml += "<div class='comment'><p>" + reader2["CommentString"] + "</p></div>";
                                    }
                                }

                                try
                                {
                                    if (Session["LoggedIn"].ToString() == "True")
                                    {
                                        Button btn = new Button();
                                        btn.ID = "VoteUp" + reader["ideaID"].ToString();
                                        btn.Text = "Vote Up";
                                        btn.Click += new EventHandler(voteUp);
                                        idea3.Controls.Add(btn);

                                        Button btn2 = new Button();
                                        btn2.ID = "VoteDown" + reader["ideaID"].ToString();
                                        btn2.Text = "Vote Down";
                                        btn2.Click += new EventHandler(voteDown);
                                        idea3.Controls.Add(btn2);

                                        tb3.Visible = true;

                                        Button btn3 = new Button();
                                        btn3.ID = "Comment" + reader["ideaID"].ToString();
                                        btn3.CommandArgument = "3";
                                        btn3.Text = "Add Comment";
                                        EventHandler eventHandler = new EventHandler(comment);
                                        btn3.Click += new EventHandler(comment);
                                        addcomment3.Controls.Add(btn3);
                                    }
                                }
                                catch
                                {

                                }
                                break;
                            case 4:
                                box4.Visible = true;
                                idea4.InnerHtml = "";
                                comments4.InnerHtml = "";
                                idea4.InnerHtml += "<h3>" + reader["IdeaTitle"] + " - Current Score = " + score.ToString() + "</h3><p>" + reader["IdeaDescription"] + "</p><div class='thumbnails' id ='buttons" + ideanum + "' runat='server'>";
                                //Populate comments
                                myQuery2 = "Select user.userActive, comment.CommentString FROM comment INNER JOIN user ON comment.userID = user.userID WHERE comment.ideaID = " + reader["IdeaID"];
                                myCommand2 = new OdbcCommand(myQuery2, myConnection);
                                reader2 = myCommand2.ExecuteReader();

                                while (reader2.Read())
                                {
                                    if (reader2["userActive"].ToString() == "True")
                                    {
                                        comments4.InnerHtml += "<div class='comment'><p>" + reader2["CommentString"] + "</p></div>";
                                    }
                                }

                                try
                                {
                                    if (Session["LoggedIn"].ToString() == "True")
                                    {
                                        Button btn = new Button();
                                        btn.ID = "VoteUp" + reader["ideaID"].ToString();
                                        btn.Text = "Vote Up";
                                        btn.Click += new EventHandler(voteUp);
                                        idea4.Controls.Add(btn);

                                        Button btn2 = new Button();
                                        btn2.ID = "VoteDown" + reader["ideaID"].ToString();
                                        btn2.Text = "Vote Down";
                                        btn2.Click += new EventHandler(voteDown);
                                        idea4.Controls.Add(btn2);

                                        tb4.Visible = true;

                                        Button btn3 = new Button();
                                        btn3.ID = "Comment" + reader["ideaID"].ToString();
                                        btn3.CommandArgument = "4";
                                        btn3.Text = "Add Comment";
                                        EventHandler eventHandler = new EventHandler(comment);
                                        btn3.Click += new EventHandler(comment);
                                        addcomment4.Controls.Add(btn3);
                                    }
                                }
                                catch
                                {

                                }
                                break;
                            case 5:
                                box5.Visible = true;
                                idea5.InnerHtml = "";
                                comments5.InnerHtml = "";
                                idea5.InnerHtml += "<h3>" + reader["IdeaTitle"] + " - Current Score = " + score.ToString() + "</h3><p>" + reader["IdeaDescription"] + "</p><div class='thumbnails' id ='buttons" + ideanum + "' runat='server'>";
                                //Populate comments
                                myQuery2 = "Select user.userActive, comment.CommentString FROM comment INNER JOIN user ON comment.userID = user.userID WHERE comment.ideaID = " + reader["IdeaID"];
                                myCommand2 = new OdbcCommand(myQuery2, myConnection);
                                reader2 = myCommand2.ExecuteReader();

                                while (reader2.Read())
                                {
                                    if (reader2["userActive"].ToString() == "True")
                                    {
                                        comments5.InnerHtml += "<div class='comment'><p>" + reader2["CommentString"] + "</p></div>";
                                    }
                                }

                                try
                                {
                                    if (Session["LoggedIn"].ToString() == "True")
                                    {
                                        Button btn = new Button();
                                        btn.ID = "VoteUp" + reader["ideaID"].ToString();
                                        btn.Text = "Vote Up";
                                        btn.Click += new EventHandler(voteUp);
                                        idea5.Controls.Add(btn);

                                        Button btn2 = new Button();
                                        btn2.ID = "VoteDown" + reader["ideaID"].ToString();
                                        btn2.Text = "Vote Down";
                                        btn2.Click += new EventHandler(voteDown);
                                        idea5.Controls.Add(btn2);

                                        tb5.Visible = true;

                                        Button btn3 = new Button();
                                        btn3.ID = "Comment" + reader["ideaID"].ToString();
                                        btn3.CommandArgument = "5";
                                        btn3.Text = "Add Comment";
                                        EventHandler eventHandler = new EventHandler(comment);
                                        btn3.Click += new EventHandler(comment);
                                        addcomment5.Controls.Add(btn3);

                                    }
                                }
                                catch
                                {

                                }
                                break;
                        }
                    }
                    ideanum += 1;
                }
            }
            Session["numberOfPages"] = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(numberOfIdeas) / 5.0));
            //Visibility of Buttons
            if (Convert.ToInt32(Session["IdeaPage"]) != 1)
            {
                Button btn = new Button();
                btn.ID = "PreviousPage";
                btn.Text = "Previous Page";
                btn.Click += new EventHandler(PreviousPage_Click);
                pagesbuttons.Controls.Add(btn);
            }
            if (Convert.ToInt32(Session["IdeaPage"]) != Convert.ToInt32(Session["numberOfPages"]))
            {
                Button btn = new Button();
                btn.ID = "NextPage";
                btn.Text = "Next Page";
                btn.Click += new EventHandler(NextPage_Click);
                pagesbuttons.Controls.Add(btn);
            }
            myConnection.Close();
        }

        protected void NextPage_Click(object sender, EventArgs e)
        {
            Session["IdeaPage"] = Convert.ToInt32(Session["IdeaPage"]) + 1;
            System.Diagnostics.Debug.WriteLine(Convert.ToInt32(Session["IdeaPage"]));
            Response.Redirect("/Index/Index.aspx");
        }

        protected void PreviousPage_Click(object sender, EventArgs e)
        {
            Session["IdeaPage"] = Convert.ToInt32(Session["IdeaPage"]) - 1;
            Response.Redirect("/Index/Index.aspx");
        }
        
        protected void Download(string file)
        {
            Response.Redirect("../Download.ashx?file=uploads/" + file);
        }

        protected void voteUp(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string ideaID = button.ID.Remove(0, 6);
            string connString;
            int ID = 1;
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            OdbcConnection myConnection = new OdbcConnection(connString);
            myConnection.Open();
            string myQuery = "SELECT MAX(UserVoteID) FROM uservote";
            OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
            OdbcDataReader reader = myCommand.ExecuteReader();
            while (reader.Read())
            {
                try
                {
                    ID = Convert.ToInt32(reader["MAX(UserVoteID)"]) + 1;
                }
                catch
                {

                }
            }

            myQuery = "SELECT UserVoteID, UserID, IdeaID FROM uservote";
            myCommand = new OdbcCommand(myQuery, myConnection);
            reader = myCommand.ExecuteReader();
            bool voted = false;
            while (reader.Read())
            {
                if (Session["LoggedUser"].ToString() == reader["UserID"].ToString())
                {
                    if (reader["IdeaID"].ToString() == ideaID)
                    {
                        voted = true;
                        myQuery = "UPDATE uservote SET Vote = '1' WHERE (UserVoteID = " + reader["UserVoteID"].ToString() + ");";
                        myCommand = new OdbcCommand(myQuery, myConnection);
                        reader = myCommand.ExecuteReader();
                    }
                }
            }
            if (!voted)
            {
                myQuery = "INSERT INTO uservote VALUES(" + ID + ", " + Session["LoggedUser"].ToString() + ", " + ideaID + ", '1')";
                myCommand = new OdbcCommand(myQuery, myConnection);
                myCommand.ExecuteNonQuery();

            }
            myConnection.Close();
            Response.Redirect("/Index/Index.aspx");

        }

        protected void voteDown(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Button Click");
            Button button = (Button)sender;
            string ideaID = button.ID.Remove(0, 8);
            string connString;
            int ID = 1;
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            OdbcConnection myConnection = new OdbcConnection(connString);
            myConnection.Open();
            string myQuery = "SELECT MAX(UserVoteID) FROM uservote";
            OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
            OdbcDataReader reader = myCommand.ExecuteReader();
            while (reader.Read())
            {
                try
                {
                    ID = Convert.ToInt32(reader["MAX(UserVoteID)"]) + 1;
                }
                catch
                {

                }
            }

            myQuery = "SELECT UserVoteID, UserID, IdeaID FROM uservote";
            myCommand = new OdbcCommand(myQuery, myConnection);
            reader = myCommand.ExecuteReader();
            bool voted = false;
            while (reader.Read())
            {
                if (Session["LoggedUser"].ToString() == reader["UserID"].ToString())
                {
                    if (reader["IdeaID"].ToString() == ideaID)
                    {
                        voted = true;
                        myQuery = "UPDATE uservote SET Vote = '-1' WHERE (UserVoteID = " + reader["UserVoteID"].ToString() + ");";
                        myCommand = new OdbcCommand(myQuery, myConnection);
                        reader = myCommand.ExecuteReader();
                    }
                }
            }
            if (!voted)
            {
                myQuery = "INSERT INTO uservote VALUES(" + ID + ", " + Session["LoggedUser"].ToString() + ", " + ideaID + ", '-1')";
                myCommand = new OdbcCommand(myQuery, myConnection);
                myCommand.ExecuteNonQuery();

            }
            myConnection.Close();
            Response.Redirect("/Index/Index.aspx");
        }

        protected void comment(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string newComment = Request.Form["tb" + button.CommandArgument];
            if (newComment != "")
            {
                string ideaID = button.ID.Remove(0, 7);
                string connString;
                int ID = 1;
                connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                OdbcConnection myConnection = new OdbcConnection(connString);
                myConnection.Open();
                string myQuery = "SELECT MAX(CommentID) FROM comment";
                OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
                OdbcDataReader reader = myCommand.ExecuteReader();
                while (reader.Read())
                {
                    try
                    {
                        ID = Convert.ToInt32(reader["MAX(CommentID)"]) + 1;
                    }
                    catch
                    {

                    }
                }
                myQuery = "INSERT INTO comment VALUES(" + ID + ", " + ideaID + ", " + Session["LoggedUser"].ToString() + ", '" + newComment + "')";
                myCommand = new OdbcCommand(myQuery, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();
                Response.Redirect("/Index/Index.aspx");
            }
        }
    }
}