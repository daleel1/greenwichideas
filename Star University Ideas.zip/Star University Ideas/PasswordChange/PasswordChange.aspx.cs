﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Helpers;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Star_University_Ideas.PasswordChange
{
    public partial class PasswordChange : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["IdeaPage"] = 1;
            if (IsPostBack)
            {
                System.Diagnostics.Debug.WriteLine("Inside Postback");
                string connString;
                connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;

                string status = "wrong";
                int userID = 0;

                string email = Request.Form["login"];
                string password = Request.Form["password"];
                string newPassword = Request.Form["passwordnew"];

                OdbcConnection myConnection = new OdbcConnection(connString);
                myConnection.Open();

                string myQuery = "SELECT userID, email, password, passwordExpiry, userActive from user";
                OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
                OdbcDataReader reader = myCommand.ExecuteReader();

                while (reader.Read())
                {
                    if (email.ToUpper() == reader["email"].ToString().ToUpper())
                    {
                        System.Diagnostics.Debug.WriteLine("Found Email");
                        if (Crypto.VerifyHashedPassword(reader["password"].ToString(), password))
                        {
                            System.Diagnostics.Debug.WriteLine("Password Matches");
                            if (reader["passwordExpiry"] != null)
                            {
                                System.Diagnostics.Debug.WriteLine("Password Expiry OK");
                                if (Convert.ToDateTime(reader["passwordExpiry"]) < DateTime.Now)
                                {
                                    System.Diagnostics.Debug.WriteLine("Password Expired");
                                    status = "passexp";
                                    break;
                                }
                            }
                            if (reader["userActive"].ToString() == "False")
                            {
                                status = "Deactive";
                            }

                            userID = Convert.ToInt32(reader["userID"]);
                            status = "good";
                            break;
                        }
                    }
                }
                if (status == "good")
                {
                    myQuery = "UPDATE user SET password = '" + Crypto.HashPassword(newPassword) + "', passwordExpiry = NULL" + " WHERE userID = " + userID;
                    myCommand = new OdbcCommand(myQuery, myConnection);
                    myCommand.ExecuteNonQuery();
                    Response.Redirect("/Login/Login.aspx");
                } else if (status == "passexp")
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('The temporary password on this account has expired, please follow the forgot password link at the bottom of this page.');", true);
                }
                else if (status == "wrong")
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Email or password incoreect, try again.');", true);
                } else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('The requested account has been deactivated, if you believe this has been done in error, please contact the System Administrator on 07415846449');", true);
                }
                myConnection.Close();
            }
        }
    }
}