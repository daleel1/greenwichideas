﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Helpers;
using System.Web.UI;
using System.Web.UI.WebControls;



namespace Star_University_Ideas
{
    public partial class SignUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["IdeaPage"] = 1;
            string connString;
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            if (IsPostBack)
            {
                int ID = 1;
                string firstName = Request.Form["firstName"];
                string lastName = Request.Form["lastName"];
                int departmentID = Convert.ToInt32(Request.Form["department"]);
                string email = Request.Form["email"];
                string password = Crypto.HashPassword(Request.Form["password"]);
                System.Diagnostics.Debug.WriteLine(password.Length);

                OdbcConnection myConnection = new OdbcConnection(connString);
                myConnection.Open();
                string myQuery = "Select MAX(userID) from user";
                OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
                OdbcDataReader reader = myCommand.ExecuteReader();
                while (reader.Read())
                {
                    try
                    {
                        ID = Convert.ToInt32(reader["MAX(userID)"]) + 1;
                    }
                    catch
                    {
                        
                    }
                    
                }

                myQuery = "INSERT INTO user VALUES (" + ID + ", 1, " + departmentID + ", '" + firstName + "', '" + lastName + "','" + email + "', 1, '" + password + "', '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "', NULL, 1)";
                System.Diagnostics.Debug.WriteLine(myQuery);
                myCommand = new OdbcCommand(myQuery, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();
                Response.Redirect("/Login/Login.aspx");
            }
            else
            {
                OdbcConnection myConnection = new OdbcConnection(connString);
                myConnection.Open();
                string myQuery = "Select DepartmentID, DepartmentString FROM department";
                OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
                OdbcDataReader reader = myCommand.ExecuteReader();
                while (reader.Read())
                {
                    department.Items.Add(new ListItem(reader["DepartmentString"].ToString(), reader["DepartmentID"].ToString()));
                }
                myConnection.Close();
            }
        }
    }
}