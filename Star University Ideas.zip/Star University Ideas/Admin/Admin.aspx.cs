﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO.Compression;
using System.IO;
using System.Text;

namespace Star_University_Ideas.Admin
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["IdeaPage"] = 1;
            //Check for QA privellages
            try
            {
                if (Session["LoggedIn"].ToString() != "True")
                {
                    Response.Redirect("/Login/Login.aspx");
                }
            }
            catch
            {
                Response.Redirect("/Login/Login.aspx");
            }
            int loggedUser = Convert.ToInt32(Session["LoggedUser"]);
            string connString;
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            OdbcConnection myConnection = new OdbcConnection(connString);
            myConnection.Open();
            string myQuery = "SELECT UserID, UserTypeID FROM user WHERE UserID=" + Session["loggedUser"].ToString();
            OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
            OdbcDataReader reader = myCommand.ExecuteReader();

            while (reader.Read())
            {
                if(reader["UserTypeID"].ToString() == "1")
                {
                    Response.Redirect("/Login/Login.aspx");
                } else if(reader["UserTypeID"].ToString() == "2") {
                    //Access level 2
                } else if(reader["UserTypeID"].ToString() == "3")
                {
                    //Access level 3
                }
            }
            if (!IsPostBack)
            {
                //Populate Lists
                myQuery = "SELECT UserID, Email FROM user";
                myCommand = new OdbcCommand(myQuery, myConnection);
                reader = myCommand.ExecuteReader();
                while (reader.Read())
                {
                    DeleteUserList.Items.Add(new ListItem(reader["Email"].ToString(), reader["UserID"].ToString()));
                }

                myQuery = "SELECT CategoryID, CategoryString FROM Category";
                myCommand = new OdbcCommand(myQuery, myConnection);
                reader = myCommand.ExecuteReader();
                while (reader.Read())
                {
                    CategoryList.Items.Add(new ListItem(reader["CategoryString"].ToString(), reader["CategoryID"].ToString()));
                }
            }
            myConnection.Close();
        }

        protected void FilesButton_Click(object sender, EventArgs e)
        {

            try
            {
                var zipFile = @"C:\IIS\Greenwich Ideas\uploads.zip";
                var files = Directory.GetFiles(@"C:\IIS\Greenwich Ideas\uploads");

                using (var archive = ZipFile.Open(zipFile, ZipArchiveMode.Create))
                {
                    foreach (var fPath in files)
                    {
                        archive.CreateEntryFromFile(fPath, Path.GetFileName(fPath));
                    }
                }
                Response.Redirect("../Download.ashx?file=uploads.zip");
                
            }
            catch
            {

                var zipFile = @"C:\IIS\Greenwich Ideas\uploads.zip";
                var files = Directory.GetFiles(@"C:\IIS\Greenwich Ideas\uploads");
                File.Delete(zipFile);
                using (var archive = ZipFile.Open(zipFile, ZipArchiveMode.Create))
                {
                    foreach (var fPath in files)
                    {
                        archive.CreateEntryFromFile(fPath, Path.GetFileName(fPath));
                    }
                }
                Response.Redirect("../Download.ashx?file=uploads.zip");
            }          
            
        }
        protected void CSVButton_Click(object sender, EventArgs e)
        {
            var csv = new StringBuilder();
            csv.Append("ID, Title, Description, Date Created, Thumbs Up, Thumbs Down, Comments" + Environment.NewLine);


            string connString;
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            OdbcConnection myConnection = new OdbcConnection(connString);
            myConnection.Open();
            string myQuery = "SELECT IdeaID, IdeaTitle, IdeaDescription, DateMade, ThumbsUp, ThumbsDown FROM idea";
            OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
            OdbcDataReader reader = myCommand.ExecuteReader();

            while (reader.Read())
            {
                var first = reader["IdeaID"].ToString();
                var second = reader["IdeaTitle"].ToString();
                var third = reader["IdeaDescription"].ToString();
                var fourth = reader["DateMade"].ToString();
                var fith = reader["ThumbsUp"].ToString();
                var sixth = reader["ThumbsDown"].ToString();
                var newLine = string.Format("{0},{1},{2},{3},{4},{5}", first, second, third, fourth, fith, sixth);

                csv.AppendLine(newLine);
            }

            File.WriteAllText("C:/IIS/Greenwich Ideas/download.csv", csv.ToString());
            myConnection.Close();
            Response.Redirect("../Download.ashx?file=download.csv");
        }

        protected void DeleteUser_Click(object sender, EventArgs e)
        {
            string connString;
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            OdbcConnection myConnection = new OdbcConnection(connString);
            myConnection.Open();
            string myQuery = "UPDATE user SET userActive = 0 WHERE (UserID = "+ DeleteUserList.SelectedValue.ToString() + ")";
            OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
            myCommand.ExecuteNonQuery();
            DeleteUserList.Items.Remove(DeleteUserList.SelectedItem);
            myConnection.Close();
        }

        protected void AddCategory_Click(object sender, EventArgs e)
        {
            int i = 0;
            string connString;
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            OdbcConnection myConnection = new OdbcConnection(connString);
            myConnection.Open();
            string myQuery = "SELECT MAX(CategoryID) from category";
            OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
            OdbcDataReader reader = myCommand.ExecuteReader();
            while (reader.Read())
            {
                i = Convert.ToInt32(reader["MAX(CategoryID)"]) + 1;
            }

            myQuery = "INSERT INTO category VALUES (" + i.ToString() + ", '" + CategoryTextBox.Text + "')";
            myCommand = new OdbcCommand(myQuery, myConnection);
            myCommand.ExecuteNonQuery();
            DeleteUserList.Items.Remove(DeleteUserList.SelectedItem);
            myConnection.Close();
            Response.Redirect("/Admin/Admin.aspx");

        }

        protected void RemoveCategory_Click(object sender, EventArgs e)
        {
            try
            {
                string connString;
                connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                OdbcConnection myConnection = new OdbcConnection(connString);
                myConnection.Open();
                string myQuery = "DELETE FROM category WHERE (CategoryID = " + CategoryList.SelectedValue.ToString() + ")";
                OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
                myCommand.ExecuteNonQuery();
                CategoryList.Items.Remove(DeleteUserList.SelectedItem);
                myConnection.Close();
            }
            catch
            {
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Category already in use and cannot be deleted.');", true);
            }
        }
    }
}