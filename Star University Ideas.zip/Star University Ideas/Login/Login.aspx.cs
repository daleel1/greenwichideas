﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
namespace Star_University_Ideas
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["IdeaPage"] = 1;
            Session["loggedIn"] = false;
            
            string connString;
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;

            if (IsPostBack)
            {
                string email = Request.Form["login"];
                string password = Request.Form["password"];
                OdbcConnection myConnection = new OdbcConnection(connString);
                myConnection.Open();
                string myQuery = "SELECT userID, email, password, lastloggedin, passwordExpiry, userActive from user";
                OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
                OdbcDataReader reader = myCommand.ExecuteReader();
                
                while (reader.Read())
                {
                    if (email.ToUpper() == reader["email"].ToString().ToUpper())
                    {
                        if(Crypto.VerifyHashedPassword(reader["password"].ToString(), password))
                        {
                            if (reader["passwordExpiry"].ToString() != "")
                            {
                                if (Convert.ToDateTime(reader["passwordExpiry"]) < DateTime.Now)
                                {
                                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('The temporary password on this account has expired, please follow the forgot password link at the bottom of this page.');", true);
                                } else {
                                    myConnection.Close();
                                    Response.Redirect("/PasswordChange/PasswordChange.aspx");
                                }
                            }
                            else if (reader["userActive"].ToString() == "False")
                            {
                                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('The requested account has been deactivated, if you believe this has been done in error, please contact the System Administrator on 07415846449');", true);
                            }
                            else
                            {
                                Session["loggedIn"] = true;
                                Session["loggedEmail"] = reader["email"].ToString();
                                Session["loggedUser"] = Convert.ToInt32(reader["userID"]);
                                Session["lastLoggedIn"] = Convert.ToString(reader["lastloggedin"]);
                                break;
                            }
                        }
                    }
                }

                if (Session["loggedIn"].ToString() == "True")
                {

                    String date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    myCommand = new OdbcCommand("UPDATE user SET lastloggedin = '" + date + "' WHERE userID = " + Convert.ToInt32(Session["loggedUser"]), myConnection);
                    myCommand.ExecuteNonQuery();
                    myConnection.Close();
                    Response.Redirect("/Index/Index.aspx");
                }
                myConnection.Close();

            }

            
        }
        
    }
}