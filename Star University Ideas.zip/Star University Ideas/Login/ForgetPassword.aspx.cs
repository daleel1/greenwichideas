﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Configuration;
using System.Web.Helpers;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Star_University_Ideas
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["IdeaPage"] = 1;
            if (IsPostBack)
            {
                System.Diagnostics.Debug.WriteLine("HI");
                string connString;
                connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;

                //Generate new password
                string newPassword = Membership.GeneratePassword(12,3);
                string expiry = DateTime.Now.AddHours(2).ToString("yyyy-MM-dd HH:mm:ss");
                string email = Request.Form["login"].ToString();
                int userID = 0;
                bool userExist = false;

                //Look up UserID
                OdbcConnection myConnection = new OdbcConnection(connString);

                myConnection.Open();
                string myQuery = "SELECT userID, email FROM user";
                OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
                OdbcDataReader reader = myCommand.ExecuteReader();

                while (reader.Read())
                {
                    if (reader["email"].ToString() == email)
                    {
                        userExist = true;
                        userID = Convert.ToInt32(reader["userID"]);
                    }
                }
                myConnection.Close();
                //Change users password
                if (userExist)
                {
                    myConnection.Open();
                    myQuery = "UPDATE user SET password = '" + Crypto.HashPassword(newPassword) + "', passwordExpiry = '" + expiry + "' WHERE userID = " + userID;
                    myCommand = new OdbcCommand(myQuery, myConnection);
                    myCommand.ExecuteNonQuery();
                    myConnection.Close();
                    //Send Confirmation
                    try
                    {
                        MailMessage msg = new MailMessage();
                        msg.From = new MailAddress("greenwichideas@gmail.com");
                        msg.To.Add(email);
                        msg.Subject = "Star Ideas Password Reset";
                        msg.Body = "Hello, \n\nA new password has been requested for your account on Star Ideas.\nYour new temporary password is:\n\n" + newPassword + "\n\nThis password will be deactivated after 2 hours, if deactivated, you will need to follow the forgot password routine again.\nWhen you log in, you will be prompted to change your password.\n\nKind Regards\nSystem Administrator";
                        SmtpClient smt = new SmtpClient();
                        smt.Host = "smtp.gmail.com";
                        NetworkCredential ntwd = new NetworkCredential();
                        ntwd.UserName = "greenwichideas@gmail.com"; //Your Email ID  
                        ntwd.Password = "GreenwichIdeas1!"; // Your Password  
                        smt.UseDefaultCredentials = true;
                        smt.Credentials = ntwd;
                        smt.Port = 587;
                        smt.EnableSsl = true;
                        smt.Send(msg);
                        //lbmsg.Text = "Email Sent Successfully";
                        //lbmsg.ForeColor = System.Drawing.Color.ForestGreen;
                    }
                    catch
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('There was a problem sending a confirmation email, please contact the system administrator on 07415846449 for assistance');", true);
                    }
                    Response.Redirect("/Login/Login.aspx");
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('No account is registered with that email address, try again or Sign Up');", true);
                }
            }
        }
    }
}