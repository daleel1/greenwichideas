﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Star_University_Ideas
{
    public partial class SubmitIdeas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["IdeaPage"] = 1;
            try
            {
                if (Session["LoggedIn"].ToString() != "True")
                {
                    Response.Redirect("/Login/Login.aspx");
                }
            } catch
            {
                Response.Redirect("/Login/Login.aspx");
            }
            
            string connString;
            connString = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            OdbcConnection myConnection = new OdbcConnection(connString);
            myConnection.Open();
            string myQuery = "SELECT CategoryID, CategoryString FROM Category";
            OdbcCommand myCommand = new OdbcCommand(myQuery, myConnection);
            OdbcDataReader reader = myCommand.ExecuteReader();
            while (reader.Read())
            {
                category.Items.Add(new ListItem(reader["CategoryString"].ToString(), reader["CategoryID"].ToString()));
            }

            if (IsPostBack)
            {
                int ID = 1;
                string ideaTitle = Request.Form["ideaTitle"].ToString();
                int category = Convert.ToInt32(Request.Form["category"]);
                string description = Request.Form["description"].ToString();
                string file = "";
                                            
                //Count the ideas
                
                myQuery = "Select MAX(ideaID) from idea";
                myCommand = new OdbcCommand(myQuery, myConnection);
                reader = myCommand.ExecuteReader();
                while (reader.Read())
                {
                    try
                    {
                        ID = Convert.ToInt32(reader["MAX(ideaID)"])+1;
                    }
                    catch
                    {
                        ID = 1;
                    }
                }
                string isFile = "No";
                //Handle File
                if (FileUploadControl.HasFile)
                {
                        string filename = Path.GetFileName(FileUploadControl.FileName);
                        FileUploadControl.SaveAs(Server.MapPath("~/uploads/") + ID.ToString() + filename);
                        file = ID.ToString() + filename;
                    isFile = "Yes";
                }

                //Add Idea to DB
                myQuery = "INSERT INTO idea VALUES (" + ID + "," + Session["LoggedUser"].ToString() + ","+category+",'" + ideaTitle + "', '" + description + "', 0, 0,'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "', '"+ file + "')";
                System.Diagnostics.Debug.WriteLine(myQuery);
                myCommand = new OdbcCommand(myQuery, myConnection);
                myCommand.ExecuteNonQuery();
                


                //Send Confirmation
                try
                {
                    MailMessage msg = new MailMessage();
                    msg.From = new MailAddress("greenwichideas@gmail.com");
                    msg.To.Add(Session["loggedEmail"].ToString());
                    msg.Subject = "Idea Submitted";
                    msg.Body = "Hello, \n\nYour idea has been submitted. Details of your idea are below:\nTitle: " + ideaTitle + "\nDescription: " + description + "\nCategory: " + category + "\nFile Uploaded: " + isFile + "\n\nKind Regards\nSystem Administrator";
                    SmtpClient smt = new SmtpClient();
                    smt.Host = "smtp.gmail.com";
                    System.Net.NetworkCredential ntwd = new NetworkCredential();
                    ntwd.UserName = "greenwichideas@gmail.com"; //Your Email ID  
                    ntwd.Password = "GreenwichIdeas1!"; // Your Password  
                    smt.UseDefaultCredentials = true;
                    smt.Credentials = ntwd;
                    smt.Port = 587;
                    smt.EnableSsl = true;
                    smt.Send(msg);
                    //lbmsg.Text = "Email Sent Successfully";
                    //lbmsg.ForeColor = System.Drawing.Color.ForestGreen;


                } catch
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('There was a problem sending a confirmation email, your idea was still submitted');", true);
                }

                
                myQuery = "SELECT user.userID, user.DepartmentID, department.QAMEmail FROM user INNER JOIN department ON department.departmentID = user.departmentID";
                myCommand = new OdbcCommand(myQuery, myConnection);
                reader = myCommand.ExecuteReader();
                string departmentEmail = "unknown";
                while (reader.Read())
                {
                    if (reader["userID"].ToString() == Session["loggedUser"].ToString())
                    {
                        System.Diagnostics.Debug.WriteLine(reader["userID"] + " " + reader["DepartmentID"] + " " + reader["QAMEmail"]);
                        departmentEmail = reader["QAMEmail"].ToString();
                    }
                }
                
                //Send Confirmation to QAC
                try
                {
                    MailMessage msg = new MailMessage();
                    msg.From = new MailAddress("greenwichideas@gmail.com");
                    msg.To.Add(departmentEmail);
                    msg.Subject = "New Idea Submitted";
                    msg.Body = "Hello, \n\nOne of the staff in your department has just submitted a new idea. Details of their idea are below:\nTitle: " + ideaTitle + "\nDescription: " + description + "\nCategory: " + category + "\nFile Uploaded: " + isFile + "\n\nKind Regards\nSystem Administrator";
                    SmtpClient smt = new SmtpClient();
                    smt.Host = "smtp.gmail.com";
                    System.Net.NetworkCredential ntwd = new NetworkCredential();
                    ntwd.UserName = "greenwichideas@gmail.com"; //Your Email ID  
                    ntwd.Password = "GreenwichIdeas1!"; // Your Password  
                    smt.UseDefaultCredentials = true;
                    smt.Credentials = ntwd;
                    smt.Port = 587;
                    smt.EnableSsl = true;
                    smt.Send(msg);
                    //lbmsg.Text = "Email Sent Successfully";
                    //lbmsg.ForeColor = System.Drawing.Color.ForestGreen;


                }
                catch
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('There was a problem sending a confirmation email to your QA Coordinator, your idea was still submitted');", true);
                }
                Response.Redirect("/Index/Index.aspx");
            }
            myConnection.Close();
        }
    }
}